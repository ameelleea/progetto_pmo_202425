package main.palazzetti.classes;

public enum TipoProdotto {
    PORTATA,
    BEVANDA,
    DESSERT,
    CAFFETTERIA
}
