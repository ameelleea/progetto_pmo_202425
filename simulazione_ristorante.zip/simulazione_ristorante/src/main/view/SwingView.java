package main.view;

public interface SwingView extends View{

}
