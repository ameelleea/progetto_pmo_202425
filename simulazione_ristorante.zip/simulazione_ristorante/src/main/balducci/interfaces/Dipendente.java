package main.balducci.interfaces;

public interface Dipendente {

    public String getIdDipendente();

    public Double getPaga();

    public void lavora();
}