package main.balducci.classes;

import main.balducci.interfaces.Ristorante;

import java.util.ArrayList;
import java.util.List;

import main.balducci.interfaces.GruppoClienti;

public class GruppoClientiFactory {

    private List<GruppoClienti> gruppiAttivi;
    private int numeroClienti;
    private int gruppiCreati;

    public GruppoClientiFactory(int numeroClienti){
        this.numeroClienti = numeroClienti;
        this.gruppiCreati = 1;
        this.gruppiAttivi = new ArrayList<>();
    }

    public void generaClienti(Ristorante ristorante){
        while(this.numeroClienti > 0){

            int max = Math.min(numeroClienti, 9); 
            int dimensioneGruppo = 2 + (int)(Math.random() * (max));

            GruppoClienti nuovGruppo = new GruppoClientiImpl(gruppiCreati, dimensioneGruppo, ristorante);
            this.gruppiAttivi.add(nuovGruppo);
            this.gruppiCreati++;
            this.numeroClienti -= dimensioneGruppo;
            System.out.println("Creato gruppo " + nuovGruppo.getId() + " con nr clienti " + nuovGruppo.getNumeroClienti());
        }
    }

    public GruppoClienti getProssimoGruppo(){
        if(gruppiAttivi.size() > 0){
        return this.gruppiAttivi.remove(0);
        }else{
            return null;
        }
    }
}
